import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "lazyemps") // select empid from sleepingemps;SQl
//@NamedQueries({
//	@NamedQuery(name="Employee.getMaxSal",query="select max(emp.esal) FROM Employee emp")
//})
//@NamedNativeQueries({
//	@NamedNativeQuery(name="fetchAll",query="select * from sleepingemps")
//})

public class Employee // select e.eid from Employee e;//JPQL update Employee set esal=esal+10000 where esal>3000
{
	@Id
	@Column(name = "empid", length = 10)
	private int eid;
	@Column(name = "empname", length = 10)
	private String ename;
	@Column(name = "salary", length = 10)
	private int esal;//update lazyemps set salary=salary+5000 where salary<50000;
					 //update Employee set esal=esal+5000 where esal<50000

	public Employee() {

	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public Employee(int eid, String ename, int esal) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
	}

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", esal=" + esal + "]";
	}
	
}
