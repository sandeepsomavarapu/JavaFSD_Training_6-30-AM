package com.ktg.jpademo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager em = emf.createEntityManager();// persist,merge,remove,find
		em.getTransaction().begin();// DML-->commit

		// ORM
//		Product product = new Product(111, "samsung", 9000, "electronics");
//
//		em.persist(product);
		Product product=em.find(Product.class,111);
		System.out.println(product);
//		product.setProductPrice(15000);
//		
//		em.merge(product);
		
		em.remove(product);

		em.getTransaction().commit();

	}

}
