package com.ktg.productmanagement.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ktg.productmanagement.model.Product;
import com.ktg.productmanagement.service.ProductService;
import com.ktg.productmanagement.service.ProductServiceImpl;

public class Client {

	public static void iterateAndPrint(List<Product> products) {
		Iterator<Product> itr;
		itr = products.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

	public static void main(String[] args) {
		int productId;
		String productName;
		float productPrice;
		String productCategory;
		List<Product> products;
		ProductService service = new ProductServiceImpl();
		Scanner scan = new Scanner(System.in);
		System.out.println("**********Product Management Application**********");
		while (true) {
			System.out.println("1)Add Product\r\n" + "2)Update Product\r\n" + "3)Delete Product\r\n"
					+ "4)Get Product\r\n" + "5)GetAll Products\r\n" + "6)GetAll Products Betbeen Prices\r\n"
					+ "7)getAll Products By Category\r\n" + "8)getAll products by productname\r\n" + "9)Exit ");
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter Product Id : ");
				productId = scan.nextInt();
				System.out.println("Enter Product Name : ");
				productName = scan.next();
				System.out.println("Enter Product Price : ");
				productPrice = scan.nextFloat();
				System.out.println("Enter Product Category : ");
				productCategory = scan.next();
				Product product = new Product(productId, productName, productPrice, productCategory);
				System.out.println(service.addProduct(product));
				break;

			case 2:
				System.out.println("Enter Exsisting Product Id : ");
				productId = scan.nextInt();
				System.out.println("Enter Product Name : ");
				productName = scan.next();
				System.out.println("Enter Product Price : ");
				productPrice = scan.nextFloat();
				System.out.println("Enter Product Category : ");
				productCategory = scan.next();
				Product updatedProduct = new Product(productId, productName, productPrice, productCategory);
				System.out.println(service.updateProduct(updatedProduct));
				break;
			case 3:
				System.out.println("Enter Exsisting Product Id : ");
				productId = scan.nextInt();
				System.out.println(service.deleteProduct(productId));
				break;
			case 4:
				System.out.println("Enter Exsisting Product Id : ");
				productId = scan.nextInt();
				System.out.println(service.getProduct(productId));
				break;
			case 5:
				products = service.getAllProducts();
				iterateAndPrint(products);
				break;
			case 6:
				System.out.println("Enter Product IntialPrice : ");
				float intialPrice = scan.nextFloat();
				System.out.println("Enter Product FinalPrice : ");
				float finalPrice = scan.nextFloat();
				products = service.getAllProductsBetweenPrices(intialPrice, finalPrice);
				iterateAndPrint(products);
				break;
			case 7:
				System.out.println("Enter Product Category : ");
				productCategory = scan.next();
				products = service.getAllProductsByCategory(productCategory);
				iterateAndPrint(products);
				break;
			case 8:
				System.out.println("Enter Product Name : ");
				productName = scan.next();
				products = service.getProductsByName(productName);
				iterateAndPrint(products);
				break;
			default:
				System.out.println("Thank you for using application!!!");
				System.exit(0);
				break;
			}
		}
	}

}
