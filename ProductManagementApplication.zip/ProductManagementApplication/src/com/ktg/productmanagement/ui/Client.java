package com.ktg.productmanagement.ui;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("**********Product Management Application**********");
		System.out.println("1)Add Product\r\n" + "2)Update Product\r\n" + "3)Delete Product\r\n" + "4)Get Product\r\n"
				+ "5)GetAll Products\r\n" + "6)GetAll Products Betbeen Prices\r\n" + "7)getAll Products By Category\r\n"
				+ "8)getAll products by productname");
		int option = scan.nextInt();

		switch (option) {
		case 1:

			break;

		case 2:

			break;
		case 3:

			break;
		case 4:

			break;
		case 5:

			break;
		case 6:

			break;
		case 7:

			break;
		case 8:

			break;
		default:
			break;
		}

	}

}
