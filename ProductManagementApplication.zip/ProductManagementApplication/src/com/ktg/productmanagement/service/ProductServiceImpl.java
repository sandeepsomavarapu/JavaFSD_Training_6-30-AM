package com.ktg.productmanagement.service;

import java.util.List;

import com.ktg.productmanagement.dao.ProductDao;
import com.ktg.productmanagement.dao.ProductDaoImpl;
import com.ktg.productmanagement.model.Product;

public class ProductServiceImpl implements ProductService {
	ProductDao dao = new ProductDaoImpl();

	@Override
	public String addProduct(Product product) {
		return dao.addProduct(product);
	}

	@Override
	public String updateProduct(Product product) {
		return dao.updateProduct(product);
	}

	@Override
	public String deleteProduct(int productId) {
		return dao.deleteProduct(productId);
	}

	@Override
	public Product getProduct(int productId) {
		return dao.getProduct(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}

	@Override
	public List<Product> getAllProductsBetweenPrices(float intialPrice, float finalPrice) {
		return dao.getAllProductsBetweenPrices(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		return dao.getAllProductsByCategory(category);
	}

	@Override
	public List<Product> getProductsByName(String productName) {
		return dao.getProductsByName(productName);
	}

}
