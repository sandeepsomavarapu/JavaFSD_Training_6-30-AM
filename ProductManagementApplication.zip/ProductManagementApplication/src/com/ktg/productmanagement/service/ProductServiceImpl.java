package com.ktg.productmanagement.service;

import java.util.List;

import com.ktg.productmanagement.model.Product;

public class ProductServiceImpl implements ProductService {

	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String updateProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProduct(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProductsBetweenPrices(float intialPrice, float finalPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getProductsByName(String productName) {
		// TODO Auto-generated method stub
		return null;
	}

}
