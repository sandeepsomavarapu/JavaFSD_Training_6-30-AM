package com.ktg.productmanagement.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map.Entry;

import com.ktg.productmanagement.model.Product;

public class ProductDaoImpl implements ProductDao {
	HashMap<Integer, Product> products = new HashMap<Integer, Product>();

	@Override
	public String addProduct(Product product) {
		products.put(product.getProductId(), product);
		return "Product Saved Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		products.put(product.getProductId(), product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		products.remove(productId);
		return "Product Deleted ....";
	}

	@Override
	public Product getProduct(int productId) {

		return products.get(productId);
	}

	@Override
	public List<Product> getAllProducts() {
		ArrayList<Product> list = new ArrayList<Product>();
		Set<Entry<Integer, Product>> entries = products.entrySet();
		Iterator<Entry<Integer, Product>> itr1 = entries.iterator();

		while (itr1.hasNext()) {
			Entry<Integer, Product> entry = itr1.next();
			list.add(entry.getValue());
		}

		return list;
	}

	@Override
	public List<Product> getAllProductsBetweenPrices(float intialPrice, float finalPrice) {// 2000 3000
		ArrayList<Product> list = new ArrayList<Product>();
		Set<Entry<Integer, Product>> entries = products.entrySet();
		Iterator<Entry<Integer, Product>> itr1 = entries.iterator();

		while (itr1.hasNext()) {
			Entry<Integer, Product> entry = itr1.next();
			Product product = entry.getValue();
			float price = product.getProductPrice();// 2500
			if (price > intialPrice && price < finalPrice)
				list.add(product);
		}
		return list;
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		ArrayList<Product> list = new ArrayList<Product>();
		Set<Entry<Integer, Product>> entries = products.entrySet();
		Iterator<Entry<Integer, Product>> itr1 = entries.iterator();

		while (itr1.hasNext()) {
			Entry<Integer, Product> entry = itr1.next();
			Product product = entry.getValue();
			String productCategory = product.getProductCategory();
			if (productCategory.equals(category))
				list.add(product);
		}

		return list;
	}

	@Override
	public List<Product> getProductsByName(String productName) {
		ArrayList<Product> list = new ArrayList<Product>();
		Set<Entry<Integer, Product>> entries = products.entrySet();
		Iterator<Entry<Integer, Product>> itr1 = entries.iterator();
		while (itr1.hasNext()) {
			Entry<Integer, Product> entry = itr1.next();
			Product product = entry.getValue();
			String name = product.getProductName();
			if (name.equals(productName))
				list.add(product);
		}

		return list;
	}

}
