package com.ktg.productmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication  //@SpringBootApplication=@Configuration,@ComponentScan,@EnableAutoConfiguration
public class SpringBootRestJpaProductManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestJpaProductManagementApplication.class, args);
	}

}
