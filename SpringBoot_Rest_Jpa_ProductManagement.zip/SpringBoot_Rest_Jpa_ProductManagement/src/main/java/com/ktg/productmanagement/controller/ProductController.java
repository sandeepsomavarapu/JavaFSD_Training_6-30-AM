package com.ktg.productmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ktg.productmanagement.entity.Product;
import com.ktg.productmanagement.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	// http://localhost:2121/products/addProduct

	@PostMapping("/addProduct")
	public String addProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	// http://localhost:2121/products/updateProduct

	@PutMapping("/updateProduct")
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	// http://localhost:2121/products/deleteProduct/123

	@DeleteMapping("/deleteProduct/{pid}")
	public String deleteProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);
	}

	// http://localhost:2121/products/getProduct/123
	@GetMapping("/getProduct/{pid}")
	public Product getProduct(@PathVariable("pid") int productId) {
		return service.getProduct(productId);
	}

	// http://localhost:2121/products/getProducts
	@GetMapping("/getProducts")
	public List<Product> getAllProducts() {
		return service.getAllProducts();
	}
	// http://localhost:2121/products/getProductsInBetween/2000
	@GetMapping("/getProductsInBetween/{iprice}/{fprice}")
	public List<Product> getAllProductInBetween(@PathVariable("iprice") int intialPrice,
			@PathVariable("fprice") int finalPrice) {
		return service.getAllProductInBetween(intialPrice, finalPrice);
	}

}
