package com.ktg.productmanagement.dao;

import java.util.List;

import com.ktg.productmanagement.entity.Product;

public interface ProductDao {
	public String addProduct(Product product);

	public String updateProduct(Product product);

	public String deleteProduct(int productId);

	public Product getProduct(int productId);

	public List<Product> getAllProducts();

	public List<Product> getAllProductInBetween(int intialPrice, int finalPrice);
}
