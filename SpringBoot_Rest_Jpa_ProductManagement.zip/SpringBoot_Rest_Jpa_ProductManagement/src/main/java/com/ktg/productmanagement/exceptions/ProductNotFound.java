package com.ktg.productmanagement.exceptions;

public class ProductNotFound extends RuntimeException {

	public ProductNotFound(String message) {
		super(message);
	}
}
