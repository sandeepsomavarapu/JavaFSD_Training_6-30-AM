package com.ktg.productmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.ktg.productmanagement.entity.Product;
import com.ktg.productmanagement.exceptions.ProductNotFound;

@Repository
public class ProductDaoImpl implements ProductDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public String addProduct(Product product) {
		entityManager.persist(product);
		return "Product Inserted Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		entityManager.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		entityManager.remove(getProduct(productId));
		return "Product Deleted Successfully";
	}

	@Override
	public Product getProduct(int productId) {
		Product product=entityManager.find(Product.class, productId);
			if (product==null) {
				throw new ProductNotFound("Enter valid product id ");
			}
			else 
				return product; 
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> query = entityManager.createQuery("select p from  Product p", Product.class);

		return query.getResultList();
	}

	@Override
	public List<Product> getAllProductInBetween(int intialPrice, int finalPrice) {
		TypedQuery<Product> query = entityManager
				.createQuery("select p from  Product p where p.productPrice between ?1 and ?2", Product.class);
		query.setParameter(1, intialPrice);
		query.setParameter(2, finalPrice);
		return query.getResultList();
	}

}
