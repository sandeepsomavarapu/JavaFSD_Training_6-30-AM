package com.ktg.productmanagement.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktg.productmanagement.dao.ProductDao;
import com.ktg.productmanagement.entity.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDao dao;

	@Override
	public String addProduct(Product product) {
			dao.save(product);
		return "Product Inserted Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		dao.save(product);
		return "Product Updated Successfully";
		
	}

	@Override
	public String deleteProduct(int productId) {
		dao.deleteById(productId);
		return "Product Deledted Successfully";
	}

	@Override
	public Product getProduct(int productId) {
				Optional<Product>product=dao.findById(productId);
		return product.get();
	}

	@Override
	public List<Product> getAllProducts() {

		return dao.findAll();
	}

	@Override
	public List<Product> getAllProductInBetween(int intialPrice, int finalPrice) {

		return dao.findByProductPriceBetween(intialPrice, finalPrice);
	}

}
