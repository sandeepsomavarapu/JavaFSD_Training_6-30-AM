 function msg(){  
 document.write("Hello welcome");  
}  