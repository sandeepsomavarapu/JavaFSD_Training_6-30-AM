package com.cg.jpacrud.service;

import java.util.List;

import com.cg.jpacrud.entities.Employee;

public interface EmployeeService {

	public abstract String addEmployee(Employee employee);//persist();

	public abstract String updateEmployee(Employee employee);//merge()

	public abstract String removeEmployee(Employee employee);//remove()

	public abstract Employee findEmployeeById(int id);//find()
	
	public abstract List<Employee> getAllEmployee();//createQuery()---->getTransaction(),begin(),commit()
}